# Harrison DeWitt
# Migler, CSC 365
# Lab 1

# students: array of arrays, each with student information. Inner array indices are as follows:
# 0: student LName
# 1: student FName
# 2: Grade
# 3: Classroom
# 4: Bus
# 5: GPA
# 6: Teacher LName
# 7: Teacher FName

import sys
from student_functions import read_stu, process


def main(argv):
    read_stu()
    cont = 1
    while (cont):
        qry = input("Enter your query: ")
        cont = process(qry)

if __name__ == "__main__":
    main(sys.argv)