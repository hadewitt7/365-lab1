# functions to pull student information
import re

# students: array of arrays, each with student information. Inner array indices are as follows:
# 0: student LName
# 1: student FName
# 2: Grade
# 3: Classroom
# 4: Bus
# 5: GPA
# 6: Teacher LName
# 7: Teacher FName

students = []
def read_stu():
    stu = open("students.txt", "r")
    stu_lines = stu.readlines()
    for l in stu_lines:
        l = l.rstrip()
        spl = l.split(",")
        spl[2] = int(spl[2])
        spl[3] = int(spl[3])
        spl[4] = int(spl[4])
        spl[5] = float(spl[5])
        students.append(spl)

def get_student(name):
    found = 0
    for entry in students:
        if entry[0] == name:
            found = 1
            print(entry[0], entry[1], entry[2], entry[3])
    if found == 0:
        print()

def get_student_bus(name):
    found = 0
    for entry in students:
        if entry[0] == name:
            found = 1
            print(entry[0], entry[1], entry[4])
    if found == 0:
        print()

def get_teacher(name):
    found = 0
    for entry in students:
        if entry[6] == name:
            found = 1
            print(entry[0], entry[1])
    if found == 0:
        print()

def get_grade(num):
    found = 0
    for entry in students:
        if entry[2] == int(num):
            found = 1
            print(entry[0], entry[1])
    if found == 0:
        print()

def get_bus(num):
    found = 0
    for entry in students:
        if entry[4] == int(num):
            found = 1
            print(entry[0], entry[1], entry[2], entry[3])
    if found == 0:
        print()

def get_max_gpa(entries):
    max_ent = [0, 0, 0, 0, 0, 0]
    for entry in entries:
        if entry[5] > max_ent[5]:
            max_ent = entry
    return max_ent

def get_min_gpa(entries):
    min_ent = [0, 0, 0, 0, 0, 10]
    for entry in entries:
        if entry[5] < min_ent[5]:
            min_ent = entry
    return min_ent
    
# TO_DO: determine behaviour for tie?
def get_grade_HL(num, hl):
    all_grade = []
    for entry in students:
        if entry[2] == int(num):
            all_grade.append(entry)
    if (hl == "H"):
        ent = get_max_gpa(all_grade)
    elif (hl == "L"):
        ent = get_min_gpa(all_grade)
    if (ent[0] != 0):
        print(ent[0], ent[1], ent[5], ent[6], ent[7], ent[4])

def get_info():
    i = 0
    while i <= 6:
        count = 0
        for entry in students:
            if int(entry[2]) is i:
                count = count + 1
        print(str(i) + ": " + str(count))
        i += 1

def get_avg(grade):
    count = 0
    total = 0
    for entry in students:
        if int(entry[2]) is int(grade):
            count = count + 1
            total += float(entry[5])
    if count != 0:
        avg = total/count
        print(grade, round(avg, 3))
    else:
        print()

def process(query):
    q = query.split(" ")
    if (re.search("^(S|Student): .+ (B|Bus)$", query)):
        get_student_bus(q[1])
        return 1
    elif (re.search("^(S|Student): .+$", query)):
        get_student(q[1])
        return 1
    elif (re.search("^(T|Teacher): .+$", query)):
        get_teacher(q[1])
        return 1
    elif (re.search("^(B|Bus): [0-9]+$", query)):
        get_bus(q[1])
        return 1
    elif (re.search("^(G|Grade): [0-9] ((H|High)|(L|Low))$", query)):
        get_grade_HL(q[1], q[2][0])
        return 1
    elif (re.search("^(G|Grade): [0-9]$", query)):
        get_grade(q[1])
        return 1
    elif (re.search("^(A|Average): [0-9]$", query)):
        get_avg(q[1])
        return 1
    elif (re.search("^(I|Info)$", query)):
        get_info()
        return 1
    elif (re.search("^(Q|Quit)$", query)):
        return 0
    else:
        print("You have entered an invlaid command, please try again")
        return 1

        

